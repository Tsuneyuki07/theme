# Dear customer, %%**USERNAME**%%

Thanks for your interest in my work, your support is truly appreciated.
Please be patient and follow all the following steps. In this archive you have the installation guide in 2 formats `(Markdown & PDF)`

%%**NONCE**%%

If you run into issue please contact me.

### Discord:

- Username: scai. (Scai#8477)
- Server: https://discord.gg/8jFChnh9dn

> This add-on is compatible with following open source projects Pterodactyl _(v1.X)_ & Pelican _(BETA)_.

## Requirements:

This add-on requires minimal modifications to **Panel**.
It requires you to have **SSH access** to **Wings** dedicated server.

> _**NOTE:**_ It's not a problem if **Wings** is installed on the same machine as **Panel**.

# Wings

> _**NOTE**_ You can skip this step if the wings is installed on the same dedicated server as panel.

1. SSH into your dedicated server and use the following command to install
   the webserver:
   `sudo apt install -y nginx`

> NOTE: Replace `pterodactyl` with `pelican`, if you are using Pelican.

2. Depending on your operating system, run the following command. This will ensure that the user has permission to access file of game servers.

- **Debian/Ubuntu:** `gppaswd -a www-data pterodactyl`
- **Centos:** `gpasswd -a nginx pterodactyl`

> _**NOTE:**_ Replace `pterodactyl` with `pelican`, if you are using Pelican.

3. Please execute the following commands, this will ensure the following folders are accesible by `www-data` user: `chmod 750 /var/lib/pterodactyl/ && chmod 750 /var/lib/pterodactyl/volumes/`

4. Only, if you have the default configuration, delete any `"default"` configuration of nginx before you start.

```bash
rm /etc/nginx/sites-available/default
rm /etc/nginx/sites-enabled/default
```

> _**NOTE:**_ Be sure before you upload there isn't any conflict of file naming.

5. Upload one of the configuration from `nginx` folder based on your usage (pterodactyl.conf or pelican.conf) to the folder path `/etc/nginx/sites-available`.
6. You will be required to modify the configuration of webserver with your own subdomain.
7. After you've edited the configuration, we will be needed to symlink the new configuration, so the webserver will be able to serve the files of game servers.

```bash
ln -s /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl-fastdl.conf
```

8. Finally, we can test if the configuration is ready to be deployed with:

```bash
nginx -t
```

If everything is configured correctly it should say succesful. Then we can proceed with:

```bash
nginx -s reload OR systemctl restart nginx
```

If there is a error, please verify the configuration again and make sure everything is correct.

# Panel

1. Open `config/pterodactyl.php` or `config/panel.php`, look for
   the following line `'P_SERVER_ALLOCATION_LIMIT' => 'allocation_limit',` and paste after it: `'P_SERVER_NODE_FQDN' => 'node.fqdn'`.

```diff
    'environment_variables' => [
        'P_SERVER_ALLOCATION_LIMIT' => 'allocation_limit',
+       'P_SERVER_NODE_FQDN' => 'node.fqdn'
    ],
```

2. You will may need to clear the cache of configuration with the following command: `php artisan optimize`

3. Navigate to the egg game you want FastDL, I will use CS:GO Egg for example.

- https://pterodactyl.test/admin/nests/egg/7
- https://pelican.test/admin/eggs/8

4. Go to the tab or section `Process Management`, search for the `Configuration Files` field.

```json
{
  "csgo/cfg/server.cfg": {
    "parser": "file",
    "find": {
      "sv_downloadurl": "sv_downloadurl \"http://{{env.P_SERVER_NODE_FQDN}}/{{env.P_SERVER_UUID}}/csgo/\"",
      "sv_allowdownload": "sv_allowdownload \"1\"",
      "sv_allowupload": "sv_allowupload \"0\""
    }
  }
}
```

---

#### Other game examples

1. Garry's Mod

```json
{
  "garrysmod/cfg/server.cfg": {
    "parser": "file",
    "find": {
      "sv_downloadurl": "sv_downloadurl \"http://{{env.P_SERVER_NODE_FQDN}}/{{env.P_SERVER_UUID}}/garrysmod/\"",
      "sv_allowdownload": "sv_allowdownload \"1\"",
      "sv_allowupload": "sv_allowupload \"0\""
    }
  }
}
```

2. MTA

```json
{
  "mods/deathmatch/mtaserver.conf": {
    "parser": "xml",
    "find": {
      "config.httpdownloadurl": "http://{{env.P_SERVER_NODE_FQDN}}/{{env.P_SERVER_UUID}}/mods/deathmatch/resource-cache/http-client-files"
    }
  }
}
```

---

### Observations:

- `"csgo/cfg/server.cfg"` represents where the configuration game file location is to configure automatically on server start the fastdownload.
- `"cstrike/server.cfg"` for CS 1.6, and at sv_downloadurl you will need to change last part with csgo in cstrike;

You will need to change the following lines in the "find", depending on your game. Be sure you save the changes.

---

5. Navigate to the install script of the egg, I will use CS:GO Egg for example.

- https://pterodactyl.test/admin/nests/egg/7/scripts
- https://pelican.test/admin/eggs/8/edit?tab=-install-script-tab

Go to last line and paste:

```bash
chmod 755 "/mnt/server"
##! FastDL Service: creaeting the default server configuration.
{
   echo '// FastDL Service'; \
   echo 'sv_downloadurl "http://'${P_SERVER_NODE_FQDN}'/'${P_SERVER_UUID}'/csgo"'; \
   echo 'sv_allowdownload 1'; \
   echo 'sv_allowupload 0'; \
} >> "/mnt/server/csgo/cfg/server.cfg"
```

---

#### Other game examples

1. CS1.6

```bash
chmod 755 "/mnt/server"
##! fastdownload
{
echo '//FastDownload'; \
 echo 'sv_downloadurl "http://'${P_SERVER_NODE_FQDN}'/'${P_SERVER_UUID}'/cstrike"'; \
 echo 'sv_allowdownload 1'; \
 echo 'sv_allowupload 0'; \
} >> "/mnt/server/cstrike/server.cfg"
```

2. Garry's Mod

```bash
chmod 755 "/mnt/server"
##! fastdownload
{
echo '//FastDownload'; \
 echo 'sv_downloadurl "http://'${P_SERVER_NODE_FQDN}'/'${P_SERVER_UUID}'/garrysmod"'; \
 echo 'sv_allowdownload 1'; \
 echo 'sv_allowupload 0'; \
} >> "/mnt/server/garrysmod/cfg/server.cfg"
```

3. MTA

```bash
chmod 755 "/mnt/server"
sed -i 's#\(<httpdownloadurl>\)[^<]\*\(</httpdownloadurl>\)#\1'"http://${P_SERVER_NODE_FQDN}/${P_SERVER_UUID}/mods/deathmatch/resource-cache/http-client-files"'\2#g' "/mnt/server/mods/deathmatch/mtaserver.conf"
```

---

### Observations:

The line above, you will need to change in your case, of the egg game.
