Hi,

Install instructions:
Connect to your server via ssh. And execute these commands:
curl "https://cdn.lewisdrake.fun/install.sh" -o /home/install.sh
cd /home && chmod 0755 install.sh && ./install.sh


If you have any questions or if you need help, contact me on discord: https://discord.gg/DstPxDzrAw

Tos:

1) Don't Resell this addon.

2) Don't give this to other people.

3) No refund.

4) Don't copy this addon

Thank you for purchasing this addon
- LewisDevelopment